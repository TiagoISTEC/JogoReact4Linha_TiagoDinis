import React, { useContext } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { GameContext } from './GameContext';

const HistoryScreen = ({ navigation }) => {
  const { history } = useContext(GameContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Histórico de Vitórias</Text>
      {/* Mostrar Historico */}
      {history.map((result, index) => (
        <Text key={index} style={styles.historyText}>{result}</Text>
      ))}
      <View style={styles.buttonContainer}>
        <Button
          title="Voltar para a tela inicial"
          onPress={() => navigation.goBack()}
          color="#FF0000"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  historyText: {
    fontSize: 18,
    marginBottom: 10,
  },
  buttonContainer: {
    marginTop: 30,
  },
});

export default HistoryScreen;