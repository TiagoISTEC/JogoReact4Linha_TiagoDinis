import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { startGame } from './GameScreen'; 

const HomeScreen = ({ navigation }) => {
  const [, setBoard] = useState([]); 
  const [, setPlayer] = useState('🔴');
  const [, setShowModal] = useState(false);

  const handleStartGame = () => {
    resetGame(); 
    setBoard(generateEmptyBoard()); 
    startGame(setBoard, setPlayer, setShowModal);
    navigation.navigate('Game'); 
  };

  const generateEmptyBoard = () => {
    return Array(6).fill(null).map(() => Array(7).fill(null));
  };

  const resetGame = () => {
    setBoard(generateEmptyBoard()); // Resetar com um novo tabuleiro
    setPlayer('🔴'); 
    setShowModal(false); 
  };

  return (
    <View style={styles.container}>
      <View style={styles.buttonContainer}>
        <Text style={styles.title}>Game 4 in line</Text>
        {/* botao iniciar */}
        <Button
          title="Iniciar Jogo"
          onPress={handleStartGame}
          color="#FF0000" 
          style={styles.button}
        />
      </View>
      <View style={styles.buttonContainer}>
        <Button
          title="Histórico"
          onPress={() => navigation.navigate('History')}
          color="#FF0000"  
          style={styles.button}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: '',
  },
  title: {
    fontSize: 50,
    marginBottom: 230,
  },
  button: {
    width: '100%',
    height: 80,
    marginBottom: 20,
    fontSize: 24,
  },
});

export default HomeScreen;
