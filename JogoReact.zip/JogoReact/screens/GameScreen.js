import React, { useContext, useState, useEffect } from 'react';
import { View, Text, Button, TouchableOpacity, StyleSheet } from 'react-native';
import Modal from 'react-native-modal';
import { GameContext } from './GameContext';

const INITIAL_BOARD = Array(6).fill(null).map(() => Array(7).fill(null));

export const startGame = (setBoard, setPlayer, setShowModal) => {
  setBoard(INITIAL_BOARD);
  setPlayer('🔴');
  setShowModal(false);
};

const GameScreen = ({ navigation }) => {
  const { history, setHistory } = useContext(GameContext);

  const [board, setBoard] = useState(INITIAL_BOARD);
  const [player, setPlayer] = useState('🔴');
  const [showModal, setShowModal] = useState(false);
  const [resultMessage, setResultMessage] = useState('');

  useEffect(() => {
    resetGame();
  }, []); // Se array de dependências está vazio, então useEffect será executado apenas uma vez após a reset inicial

  const makeMove = (col) => {
    const row = findAvailableRow(col);
    if (row === -1 || !board) return; // Verifique se tabuleiro está definido antes de continuar
  
    const newBoard = [...board];
    newBoard[row][col] = player;
    setBoard(newBoard);
  
    let newResultMessage = '';
  
    if (checkWinner(row, col)) {
      newResultMessage = `${player} venceu!`;
    } else if (checkDraw()) {
      newResultMessage = 'Empate!';
    }
  
    if (newResultMessage) {
      setResultMessage(newResultMessage);
      setShowModal(true);
  
      // Atualize o histórico 
      setHistory([...history, newResultMessage]);
    } else {
      setPlayer(player === '🔴' ? '🟡' : '🔴');
    }
  };
  

  const generateEmptyBoard = () => {
    return Array(6).fill(null).map(() => Array(7).fill(null));
  };

  const togglePlayer = () => {
    setPlayer((prevPlayer) => (prevPlayer === '🔴' ? '🟡' : '🔴'));
  };

  const resetGame = () => {
    const row = 0; // Defina o valor padrão para 'linha'
    const col = 0; // Defina o valor padrão para 'col'

    if (checkWinner(row, col) || checkDraw()) {
      const result = checkWinner(row, col) ? `${player} venceu!` : 'Empate!';
      setHistory([...history, result]);
    }

    setBoard(generateEmptyBoard()); //Reseta o tabuleiro com um novo
    togglePlayer(); // Altera os jogadores entre 🔴 e 🟡
    setShowModal(false); // Fecha os resultados
  };

  const findAvailableRow = (col) => {
    for (let row = 5; row >= 0; row--) {
      if (board[row][col] === null) {
        return row;
      }
    }
    return -1;
  };

  const checkWinner = (row, col) => {
    const directions = [

      //direçoes das jogadas

      [1, 0], 
      [0, 1], 
      [1, 1], 
      [-1, 1], 
      [1, -1], 
      [0, -1],
    ];
  
    const currentPlayer = board[row][col];
  
    if (currentPlayer) {
      for (const [dx, dy] of directions) {
        let count = 1;
  
        // Percorre em uma direção para verificar se os quadrados consecutivos com a mesma peça
        for (let i = 1; i <= 3; i++) {
          const newRow = row + i * dx;
          const newCol = col + i * dy;
  
          // Verifica se o novo Quadrado está dentro do tabuleiro
          if (
            newRow >= 0 &&
            newRow < 6 &&
            newCol >= 0 &&
            newCol < 7 &&
            board[newRow][newCol] === currentPlayer
          ) {
            count++;
          } else {
            break; 
          }
        }
  
        if (count >= 4) {
          return true; // Há um vencedor
        }
      }
    }
  
    return false; // Nenhum vencedor nesta jogada
  };
  
  

  const checkDraw = () => {
    // Verifica se todas as células estão preenchidas
    for (let row = 0; row < 6; row++) {
      for (let col = 0; col < 7; col++) {
        if (!board[row][col]) {
          return false; // Ainda há células vazias, portanto, não é um empate
        }
      }
    }
  
    // Se todas as células estiverem preenchidas não há um vencedor, é um empate
    return true;
  };
  
  

  const renderCell = (cellValue, row, col) => {
    return (
      <TouchableOpacity
        key={`${row}-${col}`}
        style={styles.cell}
        onPress={() => makeMove(col)}
        disabled={cellValue !== null}
        testID={`cell-${col}`}
      >
        <Text style={styles.cellText}>{cellValue}</Text>
      </TouchableOpacity>
    );
  };

  const renderBoard = () => {
    return (
      <View style={styles.board} testID="board">
        {board.map((row, rowIndex) => (
          <View key={rowIndex} style={styles.row}>
            {row.map((cellValue, colIndex) =>
              renderCell(cellValue, rowIndex, colIndex)
            )}
          </View>
        ))}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tabuleiro do 4 em linha</Text>
      {renderBoard()}

      {/* Botão "Voltar para a tela inicial" */}
      <View style={styles.buttonContainer}>
        <Button
          title="Voltar para a tela inicial"
          onPress={() => navigation.goBack()}
          color="#FF0000"
        />
      </View>

      {/* Mostra mensagem de jogo Ganho ou Empatado */}
      <Modal isVisible={showModal}>
        <View style={styles.modalContent}>
          <Text style={styles.resultMessage}>{resultMessage}</Text>
          <View style={styles.buttonContainer}>
            {/* Botão "Reiniciar Jogo" */}
            <Button
              title="Reiniciar Jogo"
              onPress={resetGame}
              color="#FF0000"
              style={styles.replayButton}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  resultMessage: {
    fontSize: 20,
    marginBottom: 10,
  },
  board: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  row: {
    flexDirection: 'row',
  },
  cell: {
    width: 50,
    height: 50,
    borderWidth: 1,
    borderColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cellText: {
    fontSize: 24,
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonContainer: {
    marginTop: 20,
  },
  replayButton: {
    width: '100%',
    height: 60,
    fontSize: 24,
  },
});

export default GameScreen;